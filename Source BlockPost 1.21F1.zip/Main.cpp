#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"

#include "KittyMemory/MemoryPatch.h"
#include "Menu.h"

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"

#include "UnityPlayer/Quaternion.hpp"
#include "UnityPlayer/Vector2.hpp"
#include "UnityPlayer/Vector3.hpp"
#include "UnityPlayer/RectPlayer.h"
#include "UnityPlayer/Canvas.h"
#include "UnityPlayer/MonoString.h"
#include "MateoTvGaminG/Init_Menu.h"
#include "MateoTvGaminG/OpenGL.h"
#include "MateoTvGaminG/StructurSDK.h"

ESP espOverlay;

extern "C" {
JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it
    MakeToast(env, context, OBFUSCATE("Modded by MateoTvGaminG"), Toast::LENGTH_LONG);

    const char *features[] = {
		
		    OBFUSCATE("Category_MENU AIM"), //Not counted
            OBFUSCATE("Toggle_AimBot"),
			OBFUSCATE("SeekBar_Aim Fov_0_500"),
			
            OBFUSCATE("Category_MENU ESP"), //Not counted
            OBFUSCATE("Toggle_IsPlayerLine"),
			OBFUSCATE("SeekBar_Line width_0_9"),
			OBFUSCATE("SeekBar_Color red_0_255"),
			OBFUSCATE("SeekBar_Color green_0_255"),
			OBFUSCATE("SeekBar_Color blue_0_255"),
			
			
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    switch (featNum) {
		
		case 0:
			Config.AimMenu.Aim = boolean;
			break;
			
		case 1:
			Config.AimMenu.AimFov = value;
			break;
			
		case 2:
			Config.ESPMenu.isPlayerLine = boolean;
			break;
			
		case 3:
			Config.ESPSettings.TracerWidth = value;
			break;
			
		case 4:
			Config.ESPSettings.TracerR = value;
			break;
			
		case 5:
			Config.ESPSettings.TracerG = value;
			break;
			
		case 6:
			Config.ESPSettings.TracerB = value;
			break;
        
    }
  }
}


	
	
monoString *CreateMonoString(const char *str) {    
monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0xC4D1B4);     	
    return String_CreateString(NULL, str);
}

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
	espOverlay = ESP(env, espView, canvas);
	if (espOverlay.isValid()) {
		Screen.Width = espOverlay.getWidth();
		Screen.Height = espOverlay.getHeight();
		for (int i = 0; i < 10; i++) performRGBChange();
		if (Config.ESPMenu.BoxRain) {
			Config.ESPSettings.BoxR = Config.ChamsMenu.redd;
			Config.ESPSettings.BoxG = Config.ChamsMenu.greenn;
			Config.ESPSettings.BoxB = Config.ChamsMenu.bluee;
		}
		if (Config.ESPMenu.FillRain) {
			Config.ESPSettings.FillR = Config.ChamsMenu.redd;
			Config.ESPSettings.FillG = Config.ChamsMenu.greenn;
			Config.ESPSettings.FillB = Config.ChamsMenu.bluee;
		}
		if (Config.ESPMenu.TracerRain) {
			Config.ESPSettings.TracerR = Config.ChamsMenu.redd;
			Config.ESPSettings.TracerG = Config.ChamsMenu.greenn;
			Config.ESPSettings.TracerB = Config.ChamsMenu.bluee;
		}
		if (Config.ESPMenu.NickRain) {
			Config.ESPSettings.NameR = Config.ChamsMenu.redd;
			Config.ESPSettings.NameG = Config.ChamsMenu.greenn;
			Config.ESPSettings.NameB = Config.ChamsMenu.bluee;
		}
		for (int id = 0; id < players.size(); id++) {
			 void *pl;
			 if (id < players.size()) 
				 pl = players[id];				 
				 monoString *nick;
				 if (pl != NULL && get_main() != NULL) {
					 Vector3 pos = *(Vector3 *) ((uint64_t) pl + 0x60);		
					 Vector3 pos2 = get_screenpos(get_main(), Vector3(pos.X, pos.Y, pos.Z));
					 Config.ESPSettings.playerX = pos2.X;		
					 Config.ESPSettings.playerY = pos2.Y;		
					 Config.ESPSettings.playerZ = pos2.Z;
					 Vector3 posh = *(Vector3 *) ((uint64_t) pl + 0x60);		
					 Vector3 posh2 = get_screenpos(get_main(), Vector3(pos.X, pos.Y + 1.85, pos.Z));	
					 Config.ESPSettings.headX = posh2.X;	
					 Config.ESPSettings.headY = posh2.Y;		
					 Config.ESPSettings.headZ = posh2.Z;
					 Config.ESPSettings.playerTeam = *(int *) ((uint64_t) pl + 0x1C);		
					 Config.ESPSettings.spec = *(bool *) ((uint64_t) pl + 0xD0);	
					 Config.ESPSettings.health = *(int *) ((uint64_t) pl + 0x30);		
					 nick = *(monoString* *) ((uint64_t) pl + 0xC);
			        } else {		
						 Config.ESPSettings.playerX = 0;			
						 Config.ESPSettings.playerY = 0;
						 Config.ESPSettings.playerZ = 0;	
						 Config.ESPSettings.playerTeam = 0;		
						 bool tm = true;	
						 if (Config.ESPMenu.OnlyTeam) {	
							 if (Config.ESPSettings.Team == Config.ESPSettings.playerTeam) {				
								 tm = true;
							 } else {			
								 tm = false;		
						    	}
							} else {			
							tm = true;
						 }
						 if (Config.ESPSettings.playerZ > 0 && !Config.ESPSettings.spec && Config.ESPSettings.health > 0 && tm) {
						    if (Config.ESPMenu.isPlayerLine) {
				                Color color = Color(Config.ESPSettings.TracerR, Config.ESPSettings.TracerG, Config.ESPSettings.TracerB);				
								espOverlay.DrawLine(color, Config.ESPSettings.TracerWidth, Vector2(espOverlay.getWidth() / 2, espOverlay.getHeight()), Vector2(Config.ESPSettings.playerX, espOverlay.getHeight() - Config.ESPSettings.playerY), Config.ESPMenu.Shadow);													
						 }
					 }
				 }		 
			}
		}
	}
}

// Aim
Quaternion2 GetRotationToLocation(Vector3 targetLocation, float y_bias, Vector3 myLoc){ 
	return Quaternion2::LookRotation((targetLocation + Vector3(0, y_bias, 0)) - myLoc, Vector3(0, 1, 0)); 
}

float dist(float x1, float z1, float x2, float z2) {
	return sqrt( pow((x2 - x1), 2) + pow((z2 - z1), 2) );
}

bool isFov(Vector2 vec1, Vector2 vec2, int radius) {
	int x = vec1.X;
	int y = vec1.Y;
	
	int x0 = vec2.X;
	int y0 = vec2.Y;
	if ( (pow(x - x0, 2) + pow(y - y0, 2) ) <= pow(radius, 2) ) {
		return true;
	} else {
		return false;
	}
}

void SetInputs (void *instance, void *inp) {
	if (instance != NULL && Config.AimMenu.Aim) {
		void *currentPlayer;
		bool isAim = false;
		
		if (players.size() > 0) currentPlayer = players[0];
		if (currentPlayer != NULL) {
			
			for (int idp = 0; idp < players.size(); idp++) {
				void *pl = players[idp];
				
				if (pl != NULL && get_main() != NULL) {
					
					Vector3 position = *(Vector3 *) ((uint64_t) pl + 0x60);
					void *camera = get_main();
					void *transform = get_transform(camera);
					Vector3 pos = get_position(transform);
					
					//int distanc = (int) (dist(pos.X, pos.Z, position.X, position.Z)*10000);
					
					int health = *(int *) ((uint64_t) pl + 0x30);
					int team   = *(int *) ((uint64_t) pl + 0x1C);
					
					Vector3 posP = *(Vector3 *) ((uint64_t) pl + 0x60);
					Vector3 pos2 = get_screenpos(get_main(), Vector3(posP.X, posP.Y + 0.75f, posP.Z));
					
					if (health > 0 && pos2.Z > 0) {	
						if (team == Config.ESPSettings.Team) {
							for (float y = 0; y < 1.7; y += 0.17) {
								Vector3 pos2 = get_screenpos(get_main(), Vector3(posP.X, posP.Y + y, posP.Z));							
								bool isFov1 = isFov(Vector2(pos2.X, pos2.Y), Vector2(Screen.Width / 2, Screen.Height / 2), Config.AimMenu.AimFov);					
								if (isFov1) {
									void *po = *(void* *) ((uint64_t) pl + 0x14);						
									if (checkRaycast(po, pos, 9999)) {
										currentPlayer = pl;
										isAim = true;
									}
								}
							}
						}
					}
				}
			}
		}
		if (isAim) {
			Vector3 position2 = *(Vector3 *) ((uint64_t) currentPlayer + 0x60);
			void *camera2 = get_main();
			void *transform2 = get_transform(camera2);
			Vector3 pos = get_position(transform2);
			Quaternion2 currRot = GetRotationToLocation(Vector3(position2.X, position2.Y + Config.AimMenu.aimY, position2.Z), 0, pos);
			*(Quaternion2 *) ((uint64_t) inp + 0x8) = currRot;
		}
	}
	old_SetInputs(instance, inp);
}

void clearPlayers() {
	vector<void*> pls;
	for (int i = 0; i < players.size(); i++) {
		if (players[i] != NULL) {
			pls.push_back(players[i]);
		}
	}
	players = pls;
}

bool playerFind(void *pl) {
	if (pl != NULL) {
		for (int i = 0; i < players.size(); i++) {
			if (pl == players[i]) return true;
		}
	}
	return false;
}

void (*old_playerUpdate) (...);
void playerUpdate(void *instance, void *pl) {
	if (instance != NULL & instance != NULL && (Config.ESPMenu.isPlayerLine || Config.AimMenu.Aim)) {
		if (!playerFind(pl)) players.push_back(pl);
		if (players.size() > 9) {
			players.clear();
		}
	}
	clearPlayers();
	old_playerUpdate(instance, pl);
}


void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));
    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);
    //Modded MateoTvGaminG 
	MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x619028), (void *) SetInputs, (void **) &old_SetInputs);
	
	MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x47DA3C), (void *) playerUpdate,
                   (void **) &old_playerUpdate);	
				   
	get_main = (void *(*)()) getAbsoluteAddress("libil2cpp.so", 0xDF380C);
	get_screenpos = (Vector3 (*)(void*, Vector3)) getAbsoluteAddress("libil2cpp.so", 0xDF320C);
	get_transform      = (void *(*)(void*)) getAbsoluteAddress("libil2cpp.so", 0xDF61AC);
	get_position       = (Vector3 (*)(void*)) getAbsoluteAddress("libil2cpp.so", 0xCD96E4);
	set_position       = (void (*)(void*, Vector3)) getAbsoluteAddress("libil2cpp.so", 0xCD97AC);
	checkRaycast = (bool (*)(void*, Vector3, float)) getAbsoluteAddress("libil2cpp.so", 0x492FC8);
    LOGI(OBFUSCATE("Done"));
    return NULL;
}

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

