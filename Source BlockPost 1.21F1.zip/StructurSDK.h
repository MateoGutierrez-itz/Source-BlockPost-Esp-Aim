#pragma once

void *(*get_main) ();
Vector3 (*get_screenpos) (void *cam, Vector3 inst);
Vector3 (*get_position) (void* inst);
void (*set_position) (void *tr, Vector3 poss);
void *(*get_transform) (void* inst);
bool (*checkRaycast) (void* po, Vector3 pos, float maxdist);
